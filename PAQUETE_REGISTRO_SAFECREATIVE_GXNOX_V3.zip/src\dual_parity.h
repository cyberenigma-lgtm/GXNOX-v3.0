/*
 * ============================================================================
 * GXNOX DUAL-BANK PAR/IMPAR (+1) SILICON STORAGE ENGINE
 * Reference Header in 100% ANSI C99 / Hardware Direct I/O
 *
 * Architecture: Even-Bank Direct Data (2k) + Odd-Bank Backward Mirror (2k+1)
 *               Active Bit-Rot Self-Healing & Tamper Detection Invariants
 * Author & Inventor: Jose Manuel Moreno Cano (JMMC)
 * Safe Creative Chained Prior Art:
 *   - ID: 2609046909131 (Arquitectura PAR/IMPAR +1 & Neurobus, 04/09/2026)
 *   - ID: 2609217054592 (NeuroCOBOL V3.0 Compiler & Runtime, 21/09/2026)
 * ============================================================================
 */

#ifndef DUAL_PARITY_H
#define DUAL_PARITY_H

#include "gxnox_core.h"

#ifdef __cplusplus
extern "C" {
#endif

#define NEUROCOBOL_MASK_KEY      0xA5C3F05AULL
#define NEUROCOBOL_SHIFT_PLUS1   1

/* Encode Clean Even Sector (2k) into Backward-Inverted Mirror (+1) for Odd Sector (2k+1) */
void gxnox_encode_impar_mirror(const uint8_t *par_block, uint8_t *impar_block, size_t block_size);

/* Decode Clean Even Sector from Odd Sector Mirror */
void gxnox_decode_impar_mirror(const uint8_t *impar_block, uint8_t *restored_par_block, size_t block_size);

/* Active Self-Healing Engine: Validates Parity; if corrupted, rebuilds from Odd mirror and verifies CRC */
bool gxnox_self_heal_sector(const uint8_t *impar_block, uint8_t *repaired_par_block, size_t block_size, uint32_t expected_crc);

#if defined(_WIN32)
/* Atomic Block Write and Read on Windows Systems */
bool gxnox_write_shielded_block(HANDLE hFile, uint64_t lba_par_offset, const uint8_t *clean_data, size_t block_size, uint32_t *out_crc);
bool gxnox_read_shielded_block(HANDLE hFile, uint64_t lba_par_offset, uint8_t *dest_buffer, size_t block_size, uint32_t expected_crc, bool *was_repaired);
#endif

#ifdef __cplusplus
}
#endif

#endif /* DUAL_PARITY_H */
