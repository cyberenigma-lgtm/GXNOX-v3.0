/*
 * ============================================================================
 * NEUROCOBOL 3.0 DETERMINISTIC INVARIANT ARBITER
 * Reference Specification in 100% ANSI C99
 *
 * Rules:
 *   1. Delta Offset Rule: LBA_impar - LBA_par == 1 sector (4096 bytes)
 *   2. Fixed-Point Decimal Control: Deterministic state machine, zero float error
 *   3. Parity Inversion Verification: Cryptographic backward complement check
 *
 * Author & Inventor: Jose Manuel Moreno Cano (JMMC)
 * Safe Creative Chained Prior Art:
 *   - ID: 2609046909131 (Arquitectura PAR/IMPAR +1 & Neurobus, 04/09/2026)
 *   - ID: 2609217054592 (NeuroCOBOL V3.0 Compiler & Runtime, 21/09/2026)
 * ============================================================================
 */

#ifndef NEUROCOBOL_RULES_H
#define NEUROCOBOL_RULES_H

#include "gxnox_core.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Deterministic Invariant Verifier */
bool neurocobol_verify_spatial_delta(uint64_t lba_par, uint64_t lba_impar);

/* Pre-Commit Block Parity Verifier */
bool neurocobol_verify_block_invariants(const uint8_t *par_block, const uint8_t *impar_block, size_t block_size);

#ifdef __cplusplus
}
#endif

#endif /* NEUROCOBOL_RULES_H */
